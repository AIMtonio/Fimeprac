//* Importación de todos los modelos - Ordenados - Legible
const Server = require('./server/config');

module.exports = {
    Server
}